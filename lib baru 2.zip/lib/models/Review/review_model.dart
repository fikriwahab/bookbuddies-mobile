class Review {
  final String name;
  final String judul;
  final String review;

  Review({required this.name, required this.judul, required this.review});
}
