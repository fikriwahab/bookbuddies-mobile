class Review {
  final String name;
  final String review;

  Review({required this.name, required this.review});
}
