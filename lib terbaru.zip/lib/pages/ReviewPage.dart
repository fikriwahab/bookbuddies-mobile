import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:bookbuddies/providers/review_provider.dart';

class ReviewPage extends StatefulWidget {
  const ReviewPage({Key? key}) : super(key: key);

  @override
  _ReviewPageState createState() => _ReviewPageState();
}

class _ReviewPageState extends State<ReviewPage> {
  @override
  Widget build(BuildContext context) {
    var reviewProvider = context.watch<ReviewProvider>();
    var reviews = reviewProvider.reviews;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF011D5B),
        foregroundColor: Colors.white,
        title: const Text('Review'),
      ),
      body: reviews.isNotEmpty
          ? ListView.builder(
              itemCount: reviews.length,
              itemBuilder: (context, index) {
                var review = reviews[index];
                return ListTile(
                  title: Text(review.name),
                  subtitle: Text(review.review),
                );
              },
            )
          : Center(
              child: Text("Anda belum pernah membuat review"),
            ),
    );
  }
}
